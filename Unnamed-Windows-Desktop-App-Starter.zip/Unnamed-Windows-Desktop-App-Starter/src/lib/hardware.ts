export interface HardwareTransport { listDevices(): Promise<unknown[]>; connect(id:string): Promise<void>; disconnect(id:string): Promise<void>; }
export const hardwareTransport: HardwareTransport = {async listDevices(){return[]},async connect(){},async disconnect(){}};
